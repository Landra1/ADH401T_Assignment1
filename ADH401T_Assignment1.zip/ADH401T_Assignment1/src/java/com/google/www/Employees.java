/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.google.www;

/**
 *
 * @author user
 */
class Employees {
    private int empID;
    private String empName;
    private String empPhone;
    private String empEmail;

    public Employees(int empID, String empName, String empPhone, String empEmail) {
        this.empID = empID;
        this.empName = empName;
        this.empPhone = empPhone;
        this.empEmail = empEmail;
    }

    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpPhone() {
        return empPhone;
    }

    public void setEmpPhone(String empPhone) {
        this.empPhone = empPhone;
    }

    public String getEmpEmail() {
        return empEmail;
    }

    public void setEmpEmail(String empEmail) {
        this.empEmail = empEmail;
    }
    
}
